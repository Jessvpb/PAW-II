const User = require('../model/user');

const signUp = (req,res) => {
    
};